package net.mikexxx.pmpport;

import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.tags.BlockTags;
import net.minecraft.tags.FluidTags;
import net.minecraft.util.RandomSource;
import net.minecraft.util.StringRepresentable;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.AxeItem;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.item.context.BlockPlaceContext;
import net.minecraft.world.level.BlockGetter;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.LevelAccessor;
import net.minecraft.world.level.LevelReader;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.BonemealableBlock;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SimpleWaterloggedBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.level.block.state.StateDefinition;
import net.minecraft.world.level.block.state.properties.BlockStateProperties;
import net.minecraft.world.level.block.state.properties.BooleanProperty;
import net.minecraft.world.level.block.state.properties.EnumProperty;
import net.minecraft.world.level.block.state.properties.IntegerProperty;
import net.minecraft.world.level.material.FluidState;
import net.minecraft.world.level.material.Fluids;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.shapes.CollisionContext;
import net.minecraft.world.phys.shapes.VoxelShape;

import javax.annotation.Nullable;

/**
 * Water plants.
 *  WATER_CROP : aquatic crop (two blocks, 1.7.10 style): the BOTTOM block stands in water that is exactly one block deep
 *               (on soil), the TOP block is above the water surface. Both blocks change texture with every growth stage.
 *  FLEX_CROP  : lotus / wasabi / taro - same two-block plant, in 1-deep water, OR on soil next to water, OR on mud.
 *  IMMERSED   : 2 (or 3) block plant. The bottom block stands in 1-deep water, the rest is above the surface
 *               (appears when the plant is fully grown).
 * All of them grow (random ticks, bone meal), can be waxed with honeycomb and un-waxed with an axe.
 */
public class WaterPlantBlock extends Block implements SimpleWaterloggedBlock, BonemealableBlock {
    public enum Mode { WATER_CROP, FLEX_CROP, IMMERSED }

    public enum Segment implements StringRepresentable {
        BOTTOM("bottom"), MIDDLE("middle"), TOP("top");
        private final String name;
        Segment(String n) { this.name = n; }
        @Override public String getSerializedName() { return name; }
    }

    public static final IntegerProperty STAGE = IntegerProperty.create("stage", 0, 9);
    public static final BooleanProperty WAXED = BooleanProperty.create("waxed");
    public static final BooleanProperty WATERLOGGED = BlockStateProperties.WATERLOGGED;
    public static final EnumProperty<Segment> SEGMENT = EnumProperty.create("segment", Segment.class);

    private static final VoxelShape CROP_SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 14.0D, 14.0D);
    private static final VoxelShape TALL_SHAPE = Block.box(2.0D, 0.0D, 2.0D, 14.0D, 16.0D, 14.0D);

    private final Mode mode;
    private final int stages;
    private final int height;

    public WaterPlantBlock(Properties props, Mode mode, int stages, int height) {
        super(props);
        this.mode = mode;
        this.stages = Math.max(1, Math.min(10, stages));
        this.height = Math.max(1, Math.min(3, height));
        this.registerDefaultState(this.stateDefinition.any()
                .setValue(STAGE, 0).setValue(WAXED, false).setValue(WATERLOGGED, false).setValue(SEGMENT, Segment.BOTTOM));
    }

    @Override
    protected void createBlockStateDefinition(StateDefinition.Builder<Block, BlockState> builder) {
        builder.add(STAGE, WAXED, WATERLOGGED, SEGMENT);
    }

    private int lastStage() { return stages - 1; }

    /** crops are two-block plants whose upper block exists from the moment of planting */
    private boolean twoBlockCrop() { return mode != Mode.IMMERSED && height > 1; }

    private BlockPos bottomOf(BlockPos pos, BlockState state) {
        return state.is(this) && state.getValue(SEGMENT) == Segment.TOP && twoBlockCrop() ? pos.below() : pos;
    }

    // ---------------------------------------------------------------- placement rules

    private static boolean isSoil(BlockState s) {
        return s.is(BlockTags.DIRT) || s.is(BlockTags.SAND) || s.is(Blocks.CLAY) || s.is(Blocks.GRAVEL)
                || s.is(Blocks.FARMLAND) || s.is(Blocks.MUD);
    }

    private static boolean isWater(LevelReader level, BlockPos pos) {
        return level.getFluidState(pos).is(FluidTags.WATER);
    }

    private static boolean waterNearby(LevelReader level, BlockPos pos) {
        BlockPos low = pos.below();
        for (Direction d : Direction.Plane.HORIZONTAL) {
            if (isWater(level, pos.relative(d)) || isWater(level, low.relative(d))) return true;
        }
        return false;
    }

    private boolean isPart(BlockState s, Segment seg) {
        return s.is(this) && s.getValue(SEGMENT) == seg;
    }

    @Override
    public boolean canSurvive(BlockState state, LevelReader level, BlockPos pos) {
        BlockPos below = pos.below();
        BlockState belowState = level.getBlockState(below);
        if (mode == Mode.IMMERSED) {
            Segment seg = state.getValue(SEGMENT);
            if (seg == Segment.TOP) return isPart(belowState, height == 3 ? Segment.MIDDLE : Segment.BOTTOM);
            if (seg == Segment.MIDDLE) return isPart(belowState, Segment.BOTTOM);
            return state.getValue(WATERLOGGED) && isSoil(belowState) && !isWater(level, pos.above());
        }
        if (twoBlockCrop() && state.getValue(SEGMENT) == Segment.TOP) {
            return isPart(belowState, Segment.BOTTOM) && !state.getValue(WATERLOGGED);
        }
        if (!isSoil(belowState)) return false;
        if (state.getValue(WATERLOGGED)) {
            return !isWater(level, pos.above());               // water must be exactly one block deep
        }
        if (mode == Mode.FLEX_CROP) {
            return belowState.is(Blocks.MUD) || waterNearby(level, pos);
        }
        return false;
    }

    @Nullable
    @Override
    public BlockState getStateForPlacement(BlockPlaceContext ctx) {
        FluidState fluid = ctx.getLevel().getFluidState(ctx.getClickedPos());
        boolean water = fluid.is(FluidTags.WATER) && fluid.isSource();
        BlockState state = this.defaultBlockState().setValue(WATERLOGGED, water);
        if (twoBlockCrop()) {
            BlockPos above = ctx.getClickedPos().above();
            BlockState as = ctx.getLevel().getBlockState(above);
            boolean free = (as.isAir() || as.canBeReplaced()) && as.getFluidState().isEmpty();
            if (!free) return null;
        }
        return state.canSurvive(ctx.getLevel(), ctx.getClickedPos()) ? state : null;
    }

    @Override
    public void setPlacedBy(Level level, BlockPos pos, BlockState state, @Nullable LivingEntity placer, ItemStack stack) {
        if (twoBlockCrop() && state.getValue(SEGMENT) == Segment.BOTTOM) {
            level.setBlock(pos.above(), this.defaultBlockState().setValue(SEGMENT, Segment.TOP)
                    .setValue(STAGE, state.getValue(STAGE)).setValue(WAXED, state.getValue(WAXED))
                    .setValue(WATERLOGGED, false), 3);
        }
    }

    @Override
    public FluidState getFluidState(BlockState state) {
        return state.getValue(WATERLOGGED) ? Fluids.WATER.getSource(false) : super.getFluidState(state);
    }

    @Override
    public BlockState updateShape(BlockState state, Direction dir, BlockState neighbor, LevelAccessor level,
                                  BlockPos pos, BlockPos neighborPos) {
        if (state.getValue(WATERLOGGED)) {
            level.scheduleTick(pos, Fluids.WATER, Fluids.WATER.getTickDelay(level));
        }
        if (!state.canSurvive(level, pos)) return Blocks.AIR.defaultBlockState();
        if (twoBlockCrop() && dir == Direction.UP && state.getValue(SEGMENT) == Segment.BOTTOM
                && !isPart(neighbor, Segment.TOP)) {
            return Blocks.AIR.defaultBlockState();
        }
        if (mode == Mode.IMMERSED && height > 1 && dir == Direction.UP
                && state.getValue(SEGMENT) == Segment.BOTTOM && state.getValue(STAGE) >= lastStage()) {
            Segment need = height == 3 ? Segment.MIDDLE : Segment.TOP;
            if (!isPart(neighbor, need)) return Blocks.AIR.defaultBlockState();
        }
        return state;
    }

    @Override
    public VoxelShape getShape(BlockState state, BlockGetter level, BlockPos pos, CollisionContext ctx) {
        return height > 1 ? TALL_SHAPE : CROP_SHAPE;
    }

    // ---------------------------------------------------------------- growth

    @Override
    public void randomTick(BlockState state, ServerLevel level, BlockPos pos, RandomSource random) {
        if (state.getValue(WAXED) || state.getValue(SEGMENT) != Segment.BOTTOM) return;
        if (state.getValue(STAGE) >= lastStage()) return;
        if (level.getRawBrightness(pos.above(), 0) >= 9 && random.nextInt(5) == 0) {
            grow(level, pos, state, 1);
        }
    }

    private void grow(Level level, BlockPos pos, BlockState state, int amount) {
        int next = Math.min(lastStage(), state.getValue(STAGE) + amount);
        if (next == state.getValue(STAGE)) return;
        if (mode == Mode.IMMERSED && height > 1 && next >= lastStage()) {
            for (int k = 1; k < height; k++) {
                if (!level.getBlockState(pos.above(k)).isAir()) return;      // no room above the water surface
            }
            for (int k = 1; k < height; k++) {
                Segment seg = k == height - 1 ? Segment.TOP : Segment.MIDDLE;
                level.setBlock(pos.above(k), this.defaultBlockState().setValue(SEGMENT, seg)
                        .setValue(STAGE, lastStage()).setValue(WAXED, state.getValue(WAXED)), 18);
            }
        }
        level.setBlock(pos, state.setValue(STAGE, next), 3);
        if (twoBlockCrop()) {
            BlockPos top = pos.above();
            BlockState ts = level.getBlockState(top);
            if (isPart(ts, Segment.TOP)) level.setBlock(top, ts.setValue(STAGE, next), 3);
        }
    }

    @Override
    public boolean isValidBonemealTarget(LevelReader level, BlockPos pos, BlockState state, boolean isClient) {
        if (twoBlockCrop()) return !state.getValue(WAXED) && state.getValue(STAGE) < lastStage();
        return !state.getValue(WAXED) && state.getValue(SEGMENT) == Segment.BOTTOM && state.getValue(STAGE) < lastStage();
    }

    @Override
    public boolean isBonemealSuccess(Level level, RandomSource random, BlockPos pos, BlockState state) {
        return true;
    }

    @Override
    public void performBonemeal(ServerLevel level, RandomSource random, BlockPos pos, BlockState state) {
        BlockPos bottom = bottomOf(pos, state);
        BlockState bs = level.getBlockState(bottom);
        if (bs.is(this)) grow(level, bottom, bs, 1 + random.nextInt(2));
    }

    // ---------------------------------------------------------------- waxing / axing

    private void setWax(Level level, BlockPos pos, BlockState state, boolean wax) {
        BlockPos bottom = pos;
        if (height > 1) {
            for (int k = 0; k < 3 && !(level.getBlockState(bottom).is(this) && level.getBlockState(bottom).getValue(SEGMENT) == Segment.BOTTOM); k++) {
                bottom = bottom.below();
            }
        }
        for (int k = 0; k < height; k++) {
            BlockPos p = bottom.above(k);
            BlockState s = level.getBlockState(p);
            if (s.is(this)) level.setBlock(p, s.setValue(WAXED, wax), 2);
        }
    }

    @Override
    public InteractionResult use(BlockState state, Level level, BlockPos pos, Player player, InteractionHand hand, BlockHitResult hit) {
        ItemStack held = player.getItemInHand(hand);
        boolean waxed = state.getValue(WAXED);
        if (held.is(Items.HONEYCOMB) && !waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, state, true);
                level.levelEvent(null, 3003, pos, 0);
                if (!player.getAbilities().instabuild) held.shrink(1);
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        if (held.getItem() instanceof AxeItem && waxed) {
            if (!level.isClientSide) {
                setWax(level, pos, state, false);
                level.levelEvent(null, 3004, pos, 0);
                held.hurtAndBreak(1, player, p -> p.broadcastBreakEvent(hand));
            }
            return InteractionResult.sidedSuccess(level.isClientSide);
        }
        return InteractionResult.PASS;
    }

    @Override
    public void playerWillDestroy(Level level, BlockPos pos, BlockState state, Player player) {
        if (!level.isClientSide && !player.isCreative() && twoBlockCrop() && state.getValue(SEGMENT) == Segment.TOP) {
            // breaking the upper half in survival drops the plant once (the loot table only pays out from the bottom half)
            BlockPos bp = pos.below();
            if (level.getBlockState(bp).is(this)) level.destroyBlock(bp, true, player);
        }
        if (!level.isClientSide && player.isCreative() && height > 1) {
            BlockPos bottom = pos;
            for (int k = 0; k < 3 && !(level.getBlockState(bottom).is(this) && level.getBlockState(bottom).getValue(SEGMENT) == Segment.BOTTOM); k++) {
                bottom = bottom.below();
            }
            for (int k = 0; k < height; k++) {
                BlockPos p = bottom.above(k);
                if (!p.equals(pos) && level.getBlockState(p).is(this)) {
                    level.setBlock(p, level.getBlockState(p).getValue(WATERLOGGED) ? Fluids.WATER.defaultFluidState().createLegacyBlock() : Blocks.AIR.defaultBlockState(), 35);
                }
            }
        }
        super.playerWillDestroy(level, pos, state, player);
    }
}
